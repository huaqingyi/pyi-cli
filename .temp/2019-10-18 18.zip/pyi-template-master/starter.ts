import { Application } from './src/application';

const app = new Application();
app.starter();
