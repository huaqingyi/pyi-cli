"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const application_1 = require("./application");
const app = new application_1.Application();
app.starter();

//# sourceMappingURL=sourcemaps/starter.js.map
